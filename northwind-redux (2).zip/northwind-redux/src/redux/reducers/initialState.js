const initialState = {
  currentCategory: {},
  categories: [],
  products: [],
  cart: [],
  savedProduct: {},
};
export default initialState;
